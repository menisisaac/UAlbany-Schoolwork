/**
 * Provides classes for testing implementations in the {@code storage} package.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
package storage.test;