/**
 * Provides classes for managing data on storage media.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
package storage;